<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Category;
use App\Models\Supplier;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        $query = Product::query();

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where('name', 'like', "%$search%")
                  ->orWhere('sku', 'like', "%$search%");
        }

        $products = $query->withSum('stockIns as stock_ins_sum','quantity')
            ->withSum('stockOuts as stock_outs_sum','quantity')
            ->paginate(10);

        // Dashboard stats
        $allProducts = Product::withSum('stockIns', 'quantity')
            ->withSum('stockOuts', 'quantity')->get();
        
        $totalStock = $allProducts->sum(function($p) {
            return ($p->stock_ins_sum ?? 0) - ($p->stock_outs_sum ?? 0);
        });
        
        $lowStockProducts = $allProducts->filter(function($p) {
            $stock = ($p->stock_ins_sum ?? 0) - ($p->stock_outs_sum ?? 0);
            return $stock < 10;
        });

        return view('products.index', compact('products', 'totalStock', 'lowStockProducts'));
    }

    public function create()
    {
        $categories = Category::all();
        $suppliers = Supplier::all();
        return view('products.create', compact('categories', 'suppliers'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'sku' => 'required|unique:products,sku',
            'name' => 'required|string|max:255',
            'category_id' => 'nullable|exists:categories,id',
            'supplier_id' => 'nullable|exists:suppliers,id',
            'price' => 'required|numeric|min:0',
        ]);

        Product::create($data);
        return redirect()->route('products.index')->with('success', 'Produk berhasil ditambahkan.');
    }

    public function edit(Product $product)
    {
        $categories = Category::all();
        $suppliers = Supplier::all();
        $lastCost = $product->stockIns()->orderBy('received_at', 'desc')->value('cost') ?? 0;
        return view('products.edit', compact('product', 'categories', 'suppliers', 'lastCost'));
    }

    public function update(Request $request, Product $product)
    {
        $data = $request->validate([
            'sku' => "required|unique:products,sku,{$product->id}",
            'name' => 'required|string|max:255',
            'category_id' => 'nullable|exists:categories,id',
            'supplier_id' => 'nullable|exists:suppliers,id',
            'price' => 'required|numeric|min:0',
        ]);

        $product->update($data);
        return redirect()->route('products.index')->with('success', 'Produk berhasil diperbarui.');
    }

    public function destroy(Product $product)
    {
        $product->delete();
        return redirect()->route('products.index')->with('success', 'Produk berhasil dihapus.');
    }

    public function history()
    {
        $stockInsCount = \App\Models\StockIn::count();
        $stockOutsCount = \App\Models\StockOut::count();

        $stockIns = \App\Models\StockIn::with('product')
            ->orderBy('created_at', 'desc')
            ->paginate(20, ['*'], 'page_in');

        $stockOuts = \App\Models\StockOut::with('product')
            ->orderBy('created_at', 'desc')
            ->paginate(20, ['*'], 'page_out');

        return view('products.history', compact('stockIns', 'stockOuts', 'stockInsCount', 'stockOutsCount'));
    }
}
