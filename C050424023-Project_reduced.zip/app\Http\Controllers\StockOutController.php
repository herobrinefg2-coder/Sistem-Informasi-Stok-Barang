<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\StockOut;
use Illuminate\Http\Request;

class StockOutController extends Controller
{
    public function create(Request $request)
    {
        $products = Product::orderBy('name')->get();
        $preSelectedProductId = $request->query('product_id');
        return view('stock_outs.create', compact('products', 'preSelectedProductId'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'product_id' => 'required|exists:products,id',
            'quantity' => 'required|integer|min:1',
            'sold_price' => 'nullable|numeric|min:0',
            'note' => 'nullable|string',
        ]);

        $data['issued_at'] = now();
        StockOut::create($data);

        return redirect()->route('products.index')->with('success', 'Stock keluar berhasil disimpan.');
    }
}
