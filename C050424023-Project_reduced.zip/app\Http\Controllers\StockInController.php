<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\StockIn;
use Illuminate\Http\Request;

class StockInController extends Controller
{
    public function create(Request $request)
    {
        $products = Product::orderBy('name')->get();
        $preSelectedProductId = $request->query('product_id');
        return view('stock_ins.create', compact('products', 'preSelectedProductId'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'product_id' => 'required|exists:products,id',
            'quantity' => 'required|integer|min:1',
            'cost' => 'nullable|numeric|min:0',
            'note' => 'nullable|string',
        ]);

        $data['received_at'] = now();
        StockIn::create($data);

        return redirect()->route('products.index')->with('success', 'Stock masuk berhasil disimpan.');
    }
}
