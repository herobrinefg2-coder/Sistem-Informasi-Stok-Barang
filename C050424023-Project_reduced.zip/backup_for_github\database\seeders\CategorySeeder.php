<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class CategorySeeder extends Seeder
{
    public function run()
    {
        $items = [
            ['name' => 'Elektronik', 'description' => 'Perangkat elektronik', 'created_at' => now(), 'updated_at' => now()],
            ['name' => 'ATK', 'description' => 'Alat tulis kantor', 'created_at' => now(), 'updated_at' => now()],
            ['name' => 'Makanan', 'description' => 'Produk makanan', 'created_at' => now(), 'updated_at' => now()],
        ];

        foreach ($items as $it) {
            DB::table('categories')->updateOrInsert(['name' => $it['name']], $it);
        }
    }
}
