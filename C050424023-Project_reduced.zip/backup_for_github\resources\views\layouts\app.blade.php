<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SI Stock Barang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light mb-4">
  <div class="container">
    @auth
      <a class="navbar-brand" href="{{ route('dashboard') }}">📊 SI Stock</a>
    @else
      <a class="navbar-brand" href="{{ url('/') }}">📊 SI Stock</a>
    @endauth
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      @auth
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link" href="{{ route('dashboard') }}">🏠 Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="{{ route('products.index') }}">📦 Produk</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="{{ route('products.history') }}">📊 History</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="masterNav" role="button" data-bs-toggle="dropdown">⚙️ Master</a>
            <ul class="dropdown-menu" aria-labelledby="masterNav">
              <li><a class="dropdown-item" href="{{ route('categories.index') }}">Kategori</a></li>
              <li><a class="dropdown-item" href="{{ route('suppliers.index') }}">Supplier</a></li>
            </ul>
          </li>
        </ul>
        <div class="ms-auto">
          <span class="me-3 text-muted">Hi, {{ auth()->user()->name }}</span>
          <a class="btn btn-sm btn-primary me-2" href="{{ route('stock-in.create') }}">📥 Stock In</a>
          <a class="btn btn-sm btn-danger me-2" href="{{ route('stock-out.create') }}">📤 Stock Out</a>
          <form method="POST" action="{{ route('logout') }}" style="display:inline">
              @csrf
              <button class="btn btn-sm btn-outline-secondary">🚪 Logout</button>
          </form>
        </div>
      @else
        <div class="ms-auto">
          <a class="btn btn-sm btn-outline-primary" href="{{ route('login') }}">Sign In</a>
        </div>
      @endauth
    </div>
  </div>
</nav>

<div class="container">
    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    @yield('content')
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
