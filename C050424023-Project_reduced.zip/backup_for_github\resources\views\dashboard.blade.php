@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="row mb-4">
        <div class="col-md-12">
            <h2>📊 Dashboard Stok Barang</h2>
            <p class="text-muted">Ringkasan real-time inventori</p>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="text-primary text-uppercase mb-1"><strong>📦 Total Produk</strong></div>
                    <div class="h3 mb-0">{{ $totalProducts }}</div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="text-success text-uppercase mb-1"><strong>📥 Penerimaan</strong></div>
                    <div class="h3 mb-0">{{ $totalStockIns }}</div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-left-danger shadow h-100 py-2">
                <div class="card-body">
                    <div class="text-danger text-uppercase mb-1"><strong>📤 Pengeluaran</strong></div>
                    <div class="h3 mb-0">{{ $totalStockOuts }}</div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="text-warning text-uppercase mb-1"><strong>🏷️ Kategori</strong></div>
                    <div class="h3 mb-0">{{ $totalCategories }}</div>
                </div>
            </div>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="text-info text-uppercase mb-1"><strong>🏭 Supplier</strong></div>
                    <div class="h3 mb-0">{{ $totalSuppliers }}</div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-left-secondary shadow h-100 py-2">
                <div class="card-body">
                    <div class="text-secondary text-uppercase mb-1"><strong>💰 Total Cost</strong></div>
                    <div class="h5 mb-0">Rp {{ number_format($totalCostValue, 0, ',', '.') }}</div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-left-dark shadow h-100 py-2">
                <div class="card-body">
                    <div class="text-dark text-uppercase mb-1"><strong>⚠️ Stok Rendah</strong></div>
                    <div class="h3 mb-0">{{ $lowStockCount }}</div>
                    <small class="text-muted">&lt; 10 unit</small>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card border-left-accent shadow h-100 py-2">
                <div class="card-body">
                    <div class="text-muted text-uppercase mb-1"><strong>👥 Users</strong></div>
                    <div class="h3 mb-0">{{ $totalUsers }}</div>
                </div>
            </div>
        </div>
    </div>

    <!-- Activity Section -->
    <div class="row">
        <div class="col-md-6">
            <div class="card shadow mb-4">
                <div class="card-header bg-primary text-white">
                    <h6 class="m-0">📥 Penerimaan Terbaru (Top 5)</h6>
                </div>
                <div class="card-body">
                    <table class="table table-sm table-hover">
                        <thead>
                            <tr>
                                <th>Produk</th>
                                <th>Qty</th>
                                <th>Tanggal</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($recentStockIns as $in)
                                <tr>
                                    <td>{{ $in->product->name }}</td>
                                    <td><span class="badge bg-success">{{ $in->quantity }}</span></td>
                                    <td><small>{{ $in->created_at->format('d/m/y H:i') }}</small></td>
                                </tr>
                            @empty
                                <tr><td colspan="3" class="text-muted text-center">Belum ada data</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card shadow mb-4">
                <div class="card-header bg-danger text-white">
                    <h6 class="m-0">📤 Pengeluaran Terbaru (Top 5)</h6>
                </div>
                <div class="card-body">
                    <table class="table table-sm table-hover">
                        <thead>
                            <tr>
                                <th>Produk</th>
                                <th>Qty</th>
                                <th>Tanggal</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($recentStockOuts as $out)
                                <tr>
                                    <td>{{ $out->product->name }}</td>
                                    <td><span class="badge bg-danger">{{ $out->quantity }}</span></td>
                                    <td><small>{{ $out->created_at->format('d/m/y H:i') }}</small></td>
                                </tr>
                            @empty
                                <tr><td colspan="3" class="text-muted text-center">Belum ada data</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Styling for border colors -->
    <style>
        .border-left-primary { border-left: 4px solid #007bff; }
        .border-left-success { border-left: 4px solid #28a745; }
        .border-left-danger { border-left: 4px solid #dc3545; }
        .border-left-warning { border-left: 4px solid #ffc107; }
        .border-left-info { border-left: 4px solid #17a2b8; }
        .border-left-secondary { border-left: 4px solid #6c757d; }
        .border-left-dark { border-left: 4px solid #343a40; }
        .text-primary { color: #007bff; }
        .text-success { color: #28a745; }
        .text-danger { color: #dc3545; }
        .text-warning { color: #ffc107; color: #856404; }
        .text-info { color: #17a2b8; }
    </style>
</div>
@endsection
