@extends('layouts.app')

@section('content')
<div class="mb-4">
    <h2>📋 History Stock In/Out</h2>
</div>

<!-- Navigation Tabs -->
<ul class="nav nav-tabs" role="tablist">
    <li class="nav-item">
        <a class="nav-link {{ request('tab') == 'in' || !request('tab') ? 'active' : '' }}" href="{{ route('products.history') }}?tab=in" role="tab">
            📥 Stock In ({{ $stockInsCount }})
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{ request('tab') == 'out' ? 'active' : '' }}" href="{{ route('products.history') }}?tab=out" role="tab">
            📤 Stock Out ({{ $stockOutsCount }})
        </a>
    </li>
</ul>

<div class="tab-content mt-3">
    <!-- Stock In Tab -->
    @if(request('tab') !== 'out')
    <div class="tab-pane fade show active">
        <h4>📥 Riwayat Stock In</h4>
        
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Tanggal</th>
                        <th>Produk</th>
                        <th>SKU</th>
                        <th>Quantity</th>
                        <th>Harga Satuan</th>
                        <th>Total Cost</th>
                        <th>Catatan</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($stockIns as $in)
                        <tr>
                            <td>{{ $in->received_at?->format('d/m/Y H:i') ?? $in->created_at->format('d/m/Y H:i') }}</td>
                            <td><strong>{{ $in->product->name }}</strong></td>
                            <td><code>{{ $in->product->sku }}</code></td>
                            <td>
                                <span class="badge bg-success">{{ $in->quantity }}</span>
                            </td>
                            <td>Rp {{ number_format($in->cost ?? 0, 0, ',', '.') }}</td>
                            <td>Rp {{ number_format(($in->cost ?? 0) * $in->quantity, 0, ',', '.') }}</td>
                            <td>{{ $in->note ?? '-' }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7" class="text-center text-muted">Belum ada data stock in</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        
        <nav>
            {{ $stockIns->links('pagination::bootstrap-4') }}
        </nav>
    </div>
    @endif

    <!-- Stock Out Tab -->
    @if(request('tab') == 'out')
    <div class="tab-pane fade show active">
        <h4>📤 Riwayat Stock Out</h4>
        
        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>Tanggal</th>
                        <th>Produk</th>
                        <th>SKU</th>
                        <th>Quantity</th>
                        <th>Harga Jual</th>
                        <th>Total Revenue</th>
                        <th>Catatan</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($stockOuts as $out)
                        <tr>
                            <td>{{ $out->issued_at?->format('d/m/Y H:i') ?? $out->created_at->format('d/m/Y H:i') }}</td>
                            <td><strong>{{ $out->product->name }}</strong></td>
                            <td><code>{{ $out->product->sku }}</code></td>
                            <td>
                                <span class="badge bg-danger">{{ $out->quantity }}</span>
                            </td>
                            <td>Rp {{ number_format($out->sold_price ?? 0, 0, ',', '.') }}</td>
                            <td>Rp {{ number_format(($out->sold_price ?? 0) * $out->quantity, 0, ',', '.') }}</td>
                            <td>{{ $out->note ?? '-' }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7" class="text-center text-muted">Belum ada data stock out</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        
        <nav>
            {{ $stockOuts->links('pagination::bootstrap-4') }}
        </nav>
    </div>
    @endif
</div>

<!-- Back Button -->
<div class="mt-3">
    <a href="{{ route('products.index') }}" class="btn btn-secondary">🔙 Kembali ke Produk</a>
</div>
@endsection
