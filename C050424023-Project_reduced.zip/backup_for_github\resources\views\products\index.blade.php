@extends('layouts.app')

@section('content')
<div class="mb-4">
    <h2>📦 Sistem Informasi Stock Barang</h2>
</div>

<!-- Dashboard Stats -->
<div class="row mb-4">
    <div class="col-md-4">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <h5 class="card-title">Total Stok</h5>
                <h2>{{ $totalStock }}</h2>
                <p class="card-text">Unit tersedia</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-warning text-white">
            <div class="card-body">
                <h5 class="card-title">⚠️ Stok Rendah</h5>
                <h2>{{ $lowStockProducts->count() }}</h2>
                <p class="card-text">Produk < 10 unit</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-info text-white">
            <div class="card-body">
                <h5 class="card-title">Total Produk</h5>
                <h2>{{ $products->total() }}</h2>
                <p class="card-text">Dalam sistem</p>
            </div>
        </div>
    </div>
</div>

<!-- Action Buttons -->
<div class="mb-3 d-flex gap-2">
    <a href="{{ route('products.create') }}" class="btn btn-success">➕ Tambah Produk</a>
    <a href="{{ route('products.history') }}" class="btn btn-info">📋 History Stock</a>
    <a href="{{ route('stock-in.create') }}" class="btn btn-primary">📥 Stock In</a>
    <a href="{{ route('stock-out.create') }}" class="btn btn-danger">📤 Stock Out</a>
</div>

<!-- Search Bar -->
<form method="GET" action="{{ route('products.index') }}" class="mb-3">
    <div class="input-group">
        <input type="text" name="search" class="form-control" placeholder="Cari produk atau SKU..." value="{{ request('search') }}">
        <button class="btn btn-outline-secondary" type="submit">🔍 Cari</button>
        @if(request('search'))
            <a href="{{ route('products.index') }}" class="btn btn-outline-secondary">Reset</a>
        @endif
    </div>
</form>

<!-- Low Stock Warning -->
@if($lowStockProducts->count() > 0)
    <div class="alert alert-warning">
        <strong>⚠️ Peringatan Stok Rendah:</strong>
        @foreach($lowStockProducts as $p)
            {{ $p->name }} ({{ ($p->stock_ins_sum ?? 0) - ($p->stock_outs_sum ?? 0) }} unit){{ !$loop->last ? ', ' : '' }}
        @endforeach
    </div>
@endif

<!-- Products Table -->
<div class="table-responsive">
    <table class="table table-striped table-hover">
        <thead class="table-dark">
            <tr>
                <th>SKU</th>
                <th>Nama Produk</th>
                <th>Kategori</th>
                <th>Supplier</th>
                <th>Harga</th>
                <th>Stok</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @forelse($products as $p)
                @php
                    $in = $p->stock_ins_sum ?? 0;
                    $out = $p->stock_outs_sum ?? 0;
                    $stock = $in - $out;
                    $status = $stock == 0 ? 'Habis' : ($stock < 10 ? 'Rendah' : 'Normal');
                    $badgeClass = $status == 'Habis' ? 'danger' : ($status == 'Rendah' ? 'warning' : 'success');
                @endphp
                <tr>
                    <td><code>{{ $p->sku }}</code></td>
                    <td><strong>{{ $p->name }}</strong></td>
                    <td>{{ $p->category->name ?? '-' }}</td>
                    <td>{{ $p->supplier->name ?? '-' }}</td>
                    <td>Rp {{ number_format($p->price, 0, ',', '.') }}</td>
                    <td>
                        <span class="badge bg-info">{{ $stock }}</span>
                    </td>
                    <td>
                        <span class="badge bg-{{ $badgeClass }}">{{ $status }}</span>
                    </td>
                    <td>
                        <div class="btn-group btn-group-sm" role="group">
                            <a href="{{ route('stock-in.create') }}?product_id={{ $p->id }}" class="btn btn-outline-primary" title="Stock In">📥</a>
                            <a href="{{ route('stock-out.create') }}?product_id={{ $p->id }}" class="btn btn-outline-danger" title="Stock Out">📤</a>
                            <a href="{{ route('products.edit', $p->id) }}" class="btn btn-outline-warning" title="Edit">✏️</a>
                            <form action="{{ route('products.destroy', $p->id) }}" method="POST" style="display:inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-outline-danger btn-sm" onclick="return confirm('Yakin hapus?')">🗑️</button>
                            </form>
                        </div>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="8" class="text-center text-muted">Belum ada produk</td>
                </tr>
            @endforelse
        </tbody>
    </table>
</div>

<!-- Pagination -->
<nav>
    {{ $products->links('pagination::bootstrap-4') }}
</nav>
@endsection
