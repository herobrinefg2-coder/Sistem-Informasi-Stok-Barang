@extends('layouts.app')

@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4>Suppliers</h4>
        <a href="{{ route('suppliers.create') }}" class="btn btn-primary">➕ Tambah Supplier</a>
    </div>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <table class="table table-striped">
        <thead>
            <tr>
                <th>Nama</th>
                <th>Contact</th>
                <th>Phone</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @foreach($suppliers as $sup)
                <tr>
                    <td>{{ $sup->name }}</td>
                    <td>{{ $sup->contact ?? '-' }}</td>
                    <td>{{ $sup->phone ?? '-' }}</td>
                    <td>
                        <a href="{{ route('suppliers.edit', $sup->id) }}" class="btn btn-sm btn-warning">Edit</a>
                        <form action="{{ route('suppliers.destroy', $sup->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Hapus supplier?')">
                            @csrf
                            @method('DELETE')
                            <button class="btn btn-sm btn-danger">Hapus</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>

    {{ $suppliers->links() }}
</div>
@endsection
