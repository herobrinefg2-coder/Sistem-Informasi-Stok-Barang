<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Carbon;

class ProductsTableSeeder extends Seeder
{
    public function run()
    {
        // try to pick sensible default category/supplier if exist
        $defaultCategoryId = DB::table('categories')->value('id');
        $defaultSupplierId = DB::table('suppliers')->value('id');

        $items = [
            [
                'sku' => 'P-0001',
                'name' => 'Contoh Produk A',
                'price' => 10000,
                'category_id' => $defaultCategoryId,
                'supplier_id' => $defaultSupplierId,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'sku' => 'P-0002',
                'name' => 'Contoh Produk B',
                'price' => 25000,
                'category_id' => $defaultCategoryId,
                'supplier_id' => $defaultSupplierId,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ];

        foreach ($items as $it) {
            DB::table('products')->updateOrInsert(
                ['sku' => $it['sku']],
                $it
            );
        }
    }
}
