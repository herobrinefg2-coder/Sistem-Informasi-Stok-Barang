<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SupplierSeeder extends Seeder
{
    public function run()
    {
        $items = [
            ['name' => 'PT. Sumber Supplier', 'contact' => 'Budi', 'phone' => '081234567890', 'created_at' => now(), 'updated_at' => now()],
            ['name' => 'CV. Mitra Dagang', 'contact' => 'Siti', 'phone' => '082345678901', 'created_at' => now(), 'updated_at' => now()],
        ];

        foreach ($items as $it) {
            DB::table('suppliers')->updateOrInsert(['name' => $it['name']], $it);
        }
    }
}
