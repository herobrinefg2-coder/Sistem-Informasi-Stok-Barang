@extends('layouts.app')

@section('content')
<h1>Stock In</h1>

<form method="POST" action="{{ route('stock-in.store') }}">
    @csrf
    <div class="mb-3">
        <label class="form-label">Produk</label>
        <select name="product_id" class="form-select">
            @foreach($products as $prod)
                <option value="{{ $prod->id }}" {{ request('product_id') == $prod->id ? 'selected' : '' }}>{{ $prod->sku }} - {{ $prod->name }}</option>
            @endforeach
        </select>
    </div>
    <div class="mb-3">
        <label class="form-label">Quantity</label>
        <input type="number" name="quantity" class="form-control" min="1" required>
    </div>
    <div class="mb-3">
        <label class="form-label">Cost</label>
        <input type="number" name="cost" class="form-control" step="0.01">
    </div>
    <div class="mb-3">
        <label class="form-label">Note</label>
        <textarea name="note" class="form-control"></textarea>
    </div>
    <button class="btn btn-primary">Save</button>
</form>

@endsection
