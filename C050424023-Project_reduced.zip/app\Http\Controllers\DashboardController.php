<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Category;
use App\Models\Supplier;
use App\Models\StockIn;
use App\Models\StockOut;
use App\Models\User;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        return view('dashboard', [
            'totalProducts' => Product::count(),
            'totalCategories' => Category::count(),
            'totalSuppliers' => Supplier::count(),
            'totalStockIns' => StockIn::count(),
            'totalStockOuts' => StockOut::count(),
            'totalUsers' => User::count(),
            // total inventory cost = sum of (cost per unit * quantity) for all stock ins
            'totalCostValue' => \DB::table('stock_ins')->selectRaw('COALESCE(SUM(cost * quantity),0) as total')->value('total'),
            'lowStockCount' => Product::all()->filter(function($p) {
                $ins = $p->stockIns()->sum('quantity') ?? 0;
                $outs = $p->stockOuts()->sum('quantity') ?? 0;
                return ($ins - $outs) < 10;
            })->count(),
            'recentStockIns' => StockIn::with('product')->orderBy('created_at', 'desc')->limit(5)->get(),
            'recentStockOuts' => StockOut::with('product')->orderBy('created_at', 'desc')->limit(5)->get(),
        ]);
    }
}
