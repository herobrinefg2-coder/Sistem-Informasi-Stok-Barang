<?php

return [
    // Default panel name
    'default' => env('FILAMENT_DEFAULT_PANEL', 'filament'),

    // Panel configuration
    'panels' => [
        'filament' => [
            'path' => env('FILAMENT_PATH', 'admin'),
            'auth_guard' => 'web',
            'colors' => [
                'primary' => '#3b82f6',
                'danger' => '#ef4444',
            ],
            'resources' => [
                \App\Filament\Resources\ProductResource::class,
                \App\Filament\Resources\CategoryResource::class,
                \App\Filament\Resources\SupplierResource::class,
                \App\Filament\Resources\StockInResource::class,
                \App\Filament\Resources\StockOutResource::class,
            ],
        ],
    ],

    'brand' => [
        'name' => env('FILAMENT_NAME', '📦 SI Stock'),
    ],
];
